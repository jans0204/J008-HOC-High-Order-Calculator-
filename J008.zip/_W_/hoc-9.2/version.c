char *version_array[]={
	"@(#)Release 9.2 (revision 145)",
	"@(#)Wed Sep 10 23:35:14 IDT 2008",
	"@(#)",
	"@(#)code.c 9.14",
	"@(#)hoc.h 9.10",
	"@(#)hoc.y 9.25",
	"@(#)init.c 9.2",
	"@(#)math.c 9.5",
	"@(#)memory.c 9.2",
#ifdef MSDOS
	"@(#)gamma.c 8.1",
#endif
	0
};

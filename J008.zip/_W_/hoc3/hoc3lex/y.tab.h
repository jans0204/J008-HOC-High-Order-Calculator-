#define NUMBER 257
#define VAR 258
#define BLTIN 259
#define UNDEF 260
#define UNARYMINUS 261
typedef union {
	double	val;	/* actual value */
	Symbol	*sym;	/* symbol table pointer */
} YYSTYPE;
extern YYSTYPE yylval;

#ifndef lint
/*static char yysccsid[] = "from: @(#)yaccpar	1.9 (Berkeley) 02/21/93";*/
/*static char yyrcsid[] = "$Id: skeleton.c,v 1.2 1997/06/23 02:51:17 tdukes Exp $";*/
static char yyrcsid[] = "from: Version 1.9.3 (Berkeley) 07/23/2001";
#endif
#define YYBYACC 1
#define YYMAJOR 1
#define YYMINOR 9
#define YYPATCH 3
#define yyclearin (yychar=(-1))
#define yyerrok (yyerrflag=0)
#define YYRECOVERING (yyerrflag!=0)

typedef int ZYshort;
#define YYPREFIX "yy"
#line 2 "hoc.y"
#include "hoc.h"
extern	double	Pow();
#line 5 "hoc.y"
typedef union {
	double	val;	/* actual value */
	Symbol	*sym;	/* symbol table pointer */
} YYSTYPE;
#line 25 "y.tab.c"
#define NUMBER 257
#define VAR 258
#define BLTIN 259
#define UNDEF 260
#define UNARYMINUS 261
#define YYERRCODE 256
ZYshort yylhs[] = {                                        -1,
    0,    0,    0,    0,    0,    2,    1,    1,    1,    1,
    1,    1,    1,    1,    1,    1,    1,
};
ZYshort yylen[] = {                                         2,
    0,    2,    3,    3,    3,    3,    1,    1,    1,    4,
    3,    3,    3,    3,    3,    3,    2,
};
ZYshort yydefred[] = {                                      1,
    0,    0,    7,    0,    0,    0,    2,    0,    0,    0,
    5,    0,    0,    0,    9,    0,    0,    0,    0,    0,
    0,    4,    3,    0,    0,   16,    0,    0,    0,    0,
    0,   10,
};
ZYshort yydgoto[] = {                                       1,
    9,   15,
};
ZYshort yysindex[] = {                                      0,
  -10,   -6,    0,  -48,  -16,  -39,    0,  -39,    1,   10,
    0,  -39,  -39,  -68,    0,  -33,  -39,  -39,  -39,  -39,
  -39,    0,    0,  -20,  -26,    0,  -40,  -40,  -68,  -68,
  -68,    0,
};
ZYshort yyrindex[] = {                                      0,
    0,    0,    0,   -5,    0,    0,    0,    0,    0,  -14,
    0,    0,    0,    8,    0,    0,    0,    0,    0,    0,
    0,    0,    0,   -7,    0,    0,   42,   61,   22,   49,
   56,    0,
};
ZYshort yygindex[] = {                                      0,
   99,   38,
};
#define YYTABLESIZE 249
ZYshort yytable[] = {                                       7,
    8,   19,    6,   11,    8,    6,   20,   26,   19,   17,
   22,   18,   12,   20,   32,   19,   17,   17,   18,   23,
   20,   19,   17,   13,   18,   21,   20,    9,    9,    8,
    9,   13,    9,    6,    6,    8,    8,    8,   10,    8,
    0,    8,   19,   17,    0,   18,    0,   20,   17,   17,
   17,   11,   17,   21,   17,    0,    0,    0,   14,    0,
   21,    0,   13,   13,   13,   15,   13,   21,   13,    0,
   12,    0,    0,   21,    0,    0,    0,    0,    0,    9,
    0,    0,   11,    0,   11,    0,   11,    0,    8,   14,
   14,   14,    0,   14,   21,   14,   15,   15,   15,    0,
   15,   12,   15,   12,   14,   12,   16,    0,    0,    0,
   24,   25,    0,    0,    0,   27,   28,   29,   30,   31,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    3,    4,    5,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    2,    3,    4,    5,
};
ZYshort yycheck[] = {                                      10,
   40,   42,   10,   10,   10,   45,   47,   41,   42,   43,
   10,   45,   61,   47,   41,   42,   43,   10,   45,   10,
   47,   42,   43,   40,   45,   94,   47,   42,   43,   40,
   45,   10,   47,   41,   45,   41,   42,   43,    1,   45,
   -1,   47,   42,   43,   -1,   45,   -1,   47,   41,   42,
   43,   10,   45,   94,   47,   -1,   -1,   -1,   10,   -1,
   94,   -1,   41,   42,   43,   10,   45,   94,   47,   -1,
   10,   -1,   -1,   94,   -1,   -1,   -1,   -1,   -1,   94,
   -1,   -1,   41,   -1,   43,   -1,   45,   -1,   94,   41,
   42,   43,   -1,   45,   94,   47,   41,   42,   43,   -1,
   45,   41,   47,   43,    6,   45,    8,   -1,   -1,   -1,
   12,   13,   -1,   -1,   -1,   17,   18,   19,   20,   21,
   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,
   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,
   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,
   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,
   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,
   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,
   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,
   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,
   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,
   -1,   -1,   -1,   -1,   -1,   -1,   -1,  257,  258,  259,
   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,
   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,
   -1,   -1,   -1,   -1,   -1,  256,  257,  258,  259,
};
#define YYFINAL 1
#ifndef YYDEBUG
#define YYDEBUG 0
#endif
#define YYMAXTOKEN 261
#if YYDEBUG
char *yyname[] = {
"end-of-file",0,0,0,0,0,0,0,0,0,"'\\n'",0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,0,"'('","')'","'*'","'+'",0,"'-'",0,"'/'",0,0,0,0,0,0,0,0,0,0,0,
0,0,"'='",0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,"'^'",
0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
0,0,"NUMBER","VAR","BLTIN","UNDEF","UNARYMINUS",
};
char *yyrule[] = {
"$accept : list",
"list :",
"list : list '\\n'",
"list : list asgn '\\n'",
"list : list expr '\\n'",
"list : list error '\\n'",
"asgn : VAR '=' expr",
"expr : NUMBER",
"expr : VAR",
"expr : asgn",
"expr : BLTIN '(' expr ')'",
"expr : expr '+' expr",
"expr : expr '-' expr",
"expr : expr '*' expr",
"expr : expr '/' expr",
"expr : expr '^' expr",
"expr : '(' expr ')'",
"expr : '-' expr",
};
#endif
#ifdef YYSTACKSIZE
#undef YYMAXDEPTH
#define YYMAXDEPTH YYSTACKSIZE
#else
#ifdef YYMAXDEPTH
#define YYSTACKSIZE YYMAXDEPTH
#else
#define YYSTACKSIZE 500
#define YYMAXDEPTH 500
#endif
#endif
int yydebug;
int yynerrs;
int yyerrflag;
int yychar;
ZYshort *yyssp;
YYSTYPE *yyvsp;
YYSTYPE yyval;
YYSTYPE yylval;
ZYshort yyss[YYSTACKSIZE];
YYSTYPE yyvs[YYSTACKSIZE];
#define yystacksize YYSTACKSIZE
#line 44 "hoc.y"
	/* end of grammar */
#include <stdio.h>
#include <ctype.h>
char	*progname;
int	lineno = 1;
#include <signal.h>
#include <setjmp.h>
jmp_buf begin;

main(argc, argv)	/* hoc3 */
	char *argv[];
{
//	int fpecatch();
	void fpecatch();

	progname = argv[0];
	init();
	setjmp(begin);
	signal(SIGFPE, fpecatch);
	yyparse();
}

yylex()		/* hoc3 */
{
	int c;

	while ((c=getchar()) == ' ' || c == '\t')
		;
	if (c == EOF)
		return 0;
	if (c == '.' || isdigit(c)) {	/* number */
		ungetc(c, stdin);
		scanf("%lf", &yylval.val);
		return NUMBER;
	}
	if (isalpha(c)) {
		Symbol *s;
		char sbuf[100], *p = sbuf;
		do {
			*p++ = c;
		} while ((c=getchar()) != EOF && isalnum(c));
		ungetc(c, stdin);
		*p = '\0';
		if ((s=lookup(sbuf)) == 0)
			s = install(sbuf, UNDEF, 0.0);
		yylval.sym = s;
		return s->type == UNDEF ? VAR : s->type;
	}
	if (c == '\n')
		lineno++;
	return c;
}
yyerror(s)
	char *s;
{
	warning(s, (char *)0);
}

execerror(s, t)	/* recover from run-time error */
	char *s, *t;
{
	warning(s, t);
	longjmp(begin, 0);
}

//fpecatch()	/* catch floating point exceptions */
void fpecatch()	/* catch floating point exceptions */
{
	execerror("floating point exception", (char *) 0);
}

warning(s, t)
	char *s, *t;
{
	fprintf(stderr, "%s: %s", progname, s);
	if (t && *t)
		fprintf(stderr, " %s", t);
	fprintf(stderr, " near line %d\n", lineno);
}
#line 258 "y.tab.c"
#define YYABORT goto yyabort
#define YYREJECT goto yyabort
#define YYACCEPT goto yyaccept
#define YYERROR goto yyerrlab
#ifdef __cplusplus
extern "C" { 
char * getenv();
int yylex();
int yyparse();
}

#endif
int
#if defined(__STDC__)
yyparse(void)
#else
yyparse()
#endif
{
    register int yym, yyn, yystate;
#if YYDEBUG
    register char *yys;
#ifndef __cplusplus
    extern char *getenv();
#endif

    if (yys = getenv("YYDEBUG"))
    {
        yyn = *yys;
        if (yyn >= '0' && yyn <= '9')
            yydebug = yyn - '0';
    }
#endif

    yynerrs = 0;
    yyerrflag = 0;
    yychar = (-1);

    yyssp = yyss;
    yyvsp = yyvs;
    *yyssp = yystate = 0;

yyloop:
    if ((yyn = yydefred[yystate]) != 0) goto yyreduce;
    if (yychar < 0)
    {
        if ((yychar = yylex()) < 0) yychar = 0;
#if YYDEBUG
        if (yydebug)
        {
            yys = 0;
            if (yychar <= YYMAXTOKEN) yys = yyname[yychar];
            if (!yys) yys = "illegal-symbol";
            printf("%sdebug: state %d, reading %d (%s)\n",
                    YYPREFIX, yystate, yychar, yys);
        }
#endif
    }
    if ((yyn = yysindex[yystate]) && (yyn += yychar) >= 0 &&
            yyn <= YYTABLESIZE && yycheck[yyn] == yychar)
    {
#if YYDEBUG
        if (yydebug)
            printf("%sdebug: state %d, shifting to state %d\n",
                    YYPREFIX, yystate, yytable[yyn]);
#endif
        if (yyssp >= yyss + yystacksize - 1)
        {
            goto yyoverflow;
        }
        *++yyssp = yystate = yytable[yyn];
        *++yyvsp = yylval;
        yychar = (-1);
        if (yyerrflag > 0)  --yyerrflag;
        goto yyloop;
    }
    if ((yyn = yyrindex[yystate]) && (yyn += yychar) >= 0 &&
            yyn <= YYTABLESIZE && yycheck[yyn] == yychar)
    {
        yyn = yytable[yyn];
        goto yyreduce;
    }
    if (yyerrflag) goto yyinrecovery;
    yyerror("syntax error");
#ifdef lint
    goto yyerrlab;
#endif
yyerrlab:
    ++yynerrs;
yyinrecovery:
    if (yyerrflag < 3)
    {
        yyerrflag = 3;
        for (;;)
        {
            if ((yyn = yysindex[*yyssp]) && (yyn += YYERRCODE) >= 0 &&
                    yyn <= YYTABLESIZE && yycheck[yyn] == YYERRCODE)
            {
#if YYDEBUG
                if (yydebug)
                    printf("%sdebug: state %d, error recovery shifting\
 to state %d\n", YYPREFIX, *yyssp, yytable[yyn]);
#endif
                if (yyssp >= yyss + yystacksize - 1)
                {
                    goto yyoverflow;
                }
                *++yyssp = yystate = yytable[yyn];
                *++yyvsp = yylval;
                goto yyloop;
            }
            else
            {
#if YYDEBUG
                if (yydebug)
                    printf("%sdebug: error recovery discarding state %d\n",
                            YYPREFIX, *yyssp);
#endif
                if (yyssp <= yyss) goto yyabort;
                --yyssp;
                --yyvsp;
            }
        }
    }
    else
    {
        if (yychar == 0) goto yyabort;
#if YYDEBUG
        if (yydebug)
        {
            yys = 0;
            if (yychar <= YYMAXTOKEN) yys = yyname[yychar];
            if (!yys) yys = "illegal-symbol";
            printf("%sdebug: state %d, error recovery discards token %d (%s)\n",
                    YYPREFIX, yystate, yychar, yys);
        }
#endif
        yychar = (-1);
        goto yyloop;
    }
yyreduce:
#if YYDEBUG
    if (yydebug)
        printf("%sdebug: state %d, reducing by rule %d (%s)\n",
                YYPREFIX, yystate, yyn, yyrule[yyn]);
#endif
    yym = yylen[yyn];
    yyval = yyvsp[1-yym];
    switch (yyn)
    {
case 4:
#line 21 "hoc.y"
{ printf("\t%.8g\n", yyvsp[-1].val); }
break;
case 5:
#line 22 "hoc.y"
{ yyerrok; }
break;
case 6:
#line 24 "hoc.y"
{ yyval.val=yyvsp[-2].sym->u.val=yyvsp[0].val; yyvsp[-2].sym->type = VAR; }
break;
case 8:
#line 27 "hoc.y"
{	if (yyvsp[0].sym->type == UNDEF)
		    execerror("undefined variable", yyvsp[0].sym->name);
		yyval.val = yyvsp[0].sym->u.val; }
break;
case 10:
#line 31 "hoc.y"
{ yyval.val = (*(yyvsp[-3].sym->u.ptr))(yyvsp[-1].val); }
break;
case 11:
#line 32 "hoc.y"
{ yyval.val = yyvsp[-2].val + yyvsp[0].val; }
break;
case 12:
#line 33 "hoc.y"
{ yyval.val = yyvsp[-2].val - yyvsp[0].val; }
break;
case 13:
#line 34 "hoc.y"
{ yyval.val = yyvsp[-2].val * yyvsp[0].val; }
break;
case 14:
#line 35 "hoc.y"
{
		if (yyvsp[0].val == 0.0)
			execerror("division by zero", "");
		yyval.val = yyvsp[-2].val / yyvsp[0].val; }
break;
case 15:
#line 39 "hoc.y"
{ yyval.val = Pow(yyvsp[-2].val, yyvsp[0].val); }
break;
case 16:
#line 40 "hoc.y"
{ yyval.val = yyvsp[-1].val; }
break;
case 17:
#line 41 "hoc.y"
{ yyval.val = -yyvsp[0].val; }
break;
#line 462 "y.tab.c"
    }
    yyssp -= yym;
    yystate = *yyssp;
    yyvsp -= yym;
    yym = yylhs[yyn];
    if (yystate == 0 && yym == 0)
    {
#if YYDEBUG
        if (yydebug)
            printf("%sdebug: after reduction, shifting from state 0 to\
 state %d\n", YYPREFIX, YYFINAL);
#endif
        yystate = YYFINAL;
        *++yyssp = YYFINAL;
        *++yyvsp = yyval;
        if (yychar < 0)
        {
            if ((yychar = yylex()) < 0) yychar = 0;
#if YYDEBUG
            if (yydebug)
            {
                yys = 0;
                if (yychar <= YYMAXTOKEN) yys = yyname[yychar];
                if (!yys) yys = "illegal-symbol";
                printf("%sdebug: state %d, reading %d (%s)\n",
                        YYPREFIX, YYFINAL, yychar, yys);
            }
#endif
        }
        if (yychar == 0) goto yyaccept;
        goto yyloop;
    }
    if ((yyn = yygindex[yym]) && (yyn += yystate) >= 0 &&
            yyn <= YYTABLESIZE && yycheck[yyn] == yystate)
        yystate = yytable[yyn];
    else
        yystate = yydgoto[yym];
#if YYDEBUG
    if (yydebug)
        printf("%sdebug: after reduction, shifting from state %d \
to state %d\n", YYPREFIX, *yyssp, yystate);
#endif
    if (yyssp >= yyss + yystacksize - 1)
    {
        goto yyoverflow;
    }
    *++yyssp = yystate;
    *++yyvsp = yyval;
    goto yyloop;
yyoverflow:
    yyerror("yacc stack overflow");
yyabort:
    return (1);
yyaccept:
    return (0);
}
